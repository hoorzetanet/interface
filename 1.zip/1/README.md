# CoolSwap template

### Rinkeby

- Factory: 0xb7334831c477348446b6d62785e6a7673efbdc68
- Router: 0x4e922d6e233dd48d3325b5a14d1a4cef25028c2e
- Pair hash: 0x22446cebbe518697c9abe8f2fa5789b99a987b64abf35dfe45a555f73d323dc5
